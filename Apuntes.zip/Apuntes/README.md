# Apuntes

## Contenido
- Information Gathering
  - Passive
  - Active